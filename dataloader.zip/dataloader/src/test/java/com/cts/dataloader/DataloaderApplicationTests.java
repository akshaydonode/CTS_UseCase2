package com.cts.dataloader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataloaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
